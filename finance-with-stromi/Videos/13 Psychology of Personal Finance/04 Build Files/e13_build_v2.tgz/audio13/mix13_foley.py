# ---------- per-shot foley (video 13, Head Office) ----------
def murmur(i, t0, t1, g=0.12): at(i, t0, cheer(max(0.5, t1 - t0)), g)
def flurry(i, t0, t1, g=0.5): [at(i, t, paper(0.25), g, rng.uniform(-0.5, 0.5)) for t in np.arange(t0, t1, 0.14)]
def bleeps(i, t0, t1, g=0.25): [at(i, t, bleep(1, 0.05, rng.choice([900, 1200, 1500])), g, rng.uniform(-0.6, 0.6)) for t in np.arange(t0, t1, 0.37)]
def stampx(i, t): at(i, t, stamp(), 0.7)
def chips(i, t0, n=8): [at(i, t0 + k * 0.07, clink(), 0.6, rng.uniform(-0.3, 0.3)) for k in range(n)]
def hl(i, w, n=0): return gs(i, Lt(i, w, n))
# P01 streetcar bell, envelope handed over, Hattie's gasp
at('P01', 0.3, bell(), 0.5); at('P01', q('P01', 'twelve hundred') - 1.2, paper(0.4), 0.6); at('P01', q('P01', 'twelve hundred'), ding(), 0.5)
steps('P01', 0.2, 2.0, 0.25, 0.8)
# P02 espresso machine drops onto the counter, steam puffs
at('P02', 0.65, thud(110, 0.5), 1.0); at('P02', 0.7, clink(), 0.6); at('P02', 0.75, spray(1.2), 0.25); at('P02', 0.9, register(), 0.4)
# P03 ticker tape prints, iris closes
at('P03', q('P03', 'six hundred') - 1.0, scrib(2.4), 0.5); at('P03', D('P03') - 1.0, whoosh(0.9), 0.6)
# P04 lift ding, memos flutter, staff bustle
at('P04', 0.4, ding(), 0.5); flurry('P04', 0.3, min(q('P04', 'five departments'), 6), 0.25); steps('P04', 0.3, 6.0, 0.2, 0.45)
for k in range(5): at('P04', q('P04', 'five departments') + k * 0.9, pop(), 0.3)
# P07 ladder creaks, dollar flurry
for t in np.arange(0.3, D('P07') - 0.5, 1.7): at('P07', t, creak(0.6), 0.25)
flurry('P07', hl('P07', 'PIGEONHOLE'), D('P07') - 0.5, 0.25)
# P08 two bills slap down, magnifier
at('P08', 0.5, paper(0.3), 0.7); at('P08', 0.8, paper(0.3), 0.7); at('P08', q('P08', 'look closer'), whoosh(0.5), 0.5); at('P08', q('P08', 'look closer') + 0.3, ding(), 0.3)
# P09 portrait frame, Nobel stamp
at('P09', 0.4, thud(160, 0.3), 0.5); stampx('P09', q('P09', 'nobel'))
# P10 casino murmur, chips pushed
murmur('P10', 0.2, D('P10') - 0.2, 0.18); chips('P10', hl('P10', 'ACE')); chips('P10', hl('P10', 'ACE') + 0.6, 6)
# P11 padlock click
at('P11', 0.6, click(), 1.2); at('P11', 0.65, clack(), 0.6)
# P12 meters count up, Pigeonhole slams the drawers shut
ticks('P12', q('P12', 'six hundred and seventy') - 1.0, q('P12', 'six hundred and seventy') + 1.5, 0.5); at('P12', hl('P12', 'PIGEONHOLE'), thud(120, 0.4), 0.8)
# P13 meter counts down, cards pop
ticks('P13', q('P13', 'keeps a thousand') + 1.0, q('P13', 'four hundred and forty'), 0.5); at('P13', q('P13', 'four hundred and forty'), register(), 0.4)
# P14 one page fills column by column
for ph_ in ['what you own', 'what you owe', 'what bills']: at('P14', q('P14', ph_), flip(), 0.7)
steps('P14', 0.3, 2.2, 0.25, 0.4)
# P16 switchboard chaos
bleeps('P16', 0.2, D('P16') - 0.2, 0.22); [at('P16', t, ring(), 0.25, rng.uniform(-0.5, 0.5)) for t in np.arange(0.5, D('P16') - 1.6, 3.1)]
# P17 the same call every payday
ticks('P17', 0.4, min(D('P17') - 0.3, hl('P17', 'OPAL')), 0.35); [at('P17', t, bleep(1, 0.05, 1200), 0.2) for t in np.arange(0.3, D('P17') - 0.3, 0.8)]
# P18 chalk rubbed out and rewritten
at('P18', q('P18', 'repeat studies') - 0.3, sweep(0.6), 0.6); at('P18', q('P18', 'repeat studies') + 0.2, scrib(1.4), 0.6)
# P19 Otto's door, footsteps, light turns green
at('P19', 0.2, creak(0.8), 0.5); steps('P19', 0.8, 3.4, 0.4, 0.5); at('P19', hl('P19', 'OTTO') + 1.5, ding(), 0.5); at('P19', hl('P19', 'OTTO') + 1.4, lever(), 0.5)
# P20 calm clicks
for t in np.arange(0.5, D('P20') - 0.5, 2.3): at('P20', t, click(), 0.6)
# P21 split board, tea cup
at('P21', 0.6, lever(), 0.6); at('P21', hl('P21', 'OPAL'), clink(), 0.6)
# P22 typing the index card, board powers down
keys('P22', hl('P22', 'HATTIE') + 0.2, hl('P22', 'HATTIE') + 2.2, 0.5); at('P22', hl('P22', 'HATTIE') + 2.5, powerdown(), 0.5)
# P24 night walk with the box
steps('P24', 0.2, hl('P24', 'WHAT-ELSE'), 0.4, 0.55); at('P24', hl('P24', 'WHAT-ELSE') - 0.4, whoosh(0.8), 0.4)
# P25 the ghost glides window to window
at('P25', q('P25', 'opportunity cost'), whoosh(0.9), 0.5); at('P25', q('P25', 'put on her credit card'), whoosh(0.9), 0.5); at('P25', q('P25', 'put on her credit card') + 0.8, ding(), 0.3)
# P26 sheet over the espresso machine, cat purr (low rumble)
at('P26', 0.3, paper(0.5), 0.6); at('P26', 0.5, gurgle(max(1.0, D('P26') - 1.0)), 0.12)
# P27 rain and a split boot sole
at('P27', 0.0, water(D('P27')), 0.4); at('P27', 0.6, thunder(), 0.35); at('P27', 0.8, squeak(), 0.6); at('P27', 1.6, squeak(), 0.5)
# P28 scorecard ticks
for ph_ in ['what does it cost', 'what do i get', 'what could go wrong', 'can i undo']: at('P28', q('P28', ph_), scrib(0.5), 0.6); at('P28', q('P28', ph_) + 0.1, pop(), 0.3)
# P30 circus: drumroll as Ace climbs, crowd gasp
murmur('P30', 0.2, D('P30') - 0.2, 0.12); at('P30', 0.4, drumroll(max(0.6, min(hl('P30', 'ACE') - 0.5, 6) - 0.4)), 0.6); at('P30', hl('P30', 'ACE'), cheer(2.0), 0.35)
# P31 meters pop on
at('P31', q('P31', 'risk tolerance'), thud(150, 0.3), 0.6); at('P31', q('P31', 'risk capacity'), thud(150, 0.3), 0.6); at('P31', q('P31', 'giant heart'), whoosh(0.7), 0.5)
# P32 wire wobbles, crash arrows
for t in np.arange(0.4, D('P32') - 0.5, 1.4): at('P32', t, creak(0.5), 0.3)
at('P32', 0.6, thud(80, 0.6), 0.7); at('P32', q('P32', '2008'), thud(70, 0.8), 0.9); at('P32', hl('P32', 'ACE'), cheer(1.2), 0.25)
# P33 low wire with a net
murmur('P33', 0.2, D('P33') - 0.2, 0.1); at('P33', q('P33', 'jump off'), sad_tb(), 0.35)
# P34 Ace climbs down, three questions
for t in np.arange(0.3, 3.2, 0.35): at('P34', t, clack(), 0.35)
for ph_ in ['what happens if', 'how long', 'would being wrong']: at('P34', q('P34', ph_), pop(), 0.4)
# P35 practice wire, pillow, scores
at('P35', 1.0, ding(), 0.4); at('P35', 1.1, cheer(1.8), 0.3); at('P35', hl('P35', 'ACE'), thud(90, 0.4), 0.5)
# P37 typewriter
keys('P37', 0.4, min(D('P37') - 0.3, 4.5), 0.45); at('P37', min(D('P37') - 0.3, 4.6), cbell(), 0.4)
# P38-P41 rules stamped onto the plaque
stampx('P38', q('P38', 'rule one')); stampx('P39', q('P39', 'rule two')); stampx('P39', q('P39', 'rule three')); stampx('P40', q('P40', 'rule four')); stampx('P41', q('P41', 'rule five')); stampx('P41', q('P41', 'rule six'))
at('P39', q('P39', 'rule two') + 1.0, ticks if False else pop(), 0.3)
at('P40', 0.3, engine(1.8), 0.35); at('P40', 2.0, honk(), 0.6); at('P40', q('P40', 'over six years'), flip(), 0.8); at('P40', q('P40', 'over six years') + 0.4, register(), 0.35)
at('P41', 0.8, paper(0.3), 0.6); at('P41', q('P41', 'warning sign'), rattle(1.6), 0.7); at('P41', q('P41', 'warning sign') + 0.2, saw_s(), 0.6)
# P43 four easels fill in
for ph_ in ['what you own', 'what you owe', 'what leaves', 'what you actually want']: at('P43', q('P43', ph_), scrib(0.9), 0.55)
# P44 lines drawn, the gym blinks
at('P44', 1.0, scrib(2.0), 0.55); [at('P44', t, bleep(1, 0.05, 700), 0.2) for t in np.arange(1.2, hl('P44', 'HATTIE'), 0.8)]; at('P44', hl('P44', 'HATTIE'), sad_tb(), 0.3)
# P45 sticky note slapped on
at('P45', q('P45', 'pick the one') + 0.2, paper(0.25), 0.8); at('P45', q('P45', 'pick the one') + 0.3, thud(200, 0.2), 0.5)
# P47 five rule cards pop up
for ph_ in ['one.', 'two.', 'three.', 'four.', 'and five']:
    try: at('P47', q('P47', ph_), pop(), 0.6)
    except Exception: pass
# P48 a few months later: same streetcar, same bonus, quick trip into the head
at('P48', 0.3, bell(), 0.45); at('P48', q('P48', 'same twelve hundred') - 1.0, paper(0.4), 0.6); at('P48', q('P48', 'checked the rules') - 0.4, whoosh(0.7), 0.6); at('P48', hl('P48', 'HATTIE') - 0.3, whoosh(0.7), 0.6); at('P48', hl('P48', 'PIGEONHOLE'), ding(), 0.4)
# P49 kitchen: SOLD tag, pot bubbling, cake
at('P49', 0.5, register(), 0.4); at('P49', 0.3, gurgle(max(1.0, D('P49') - 1.5)), 0.18); at('P49', hl('P49', 'HATTIE'), clink(), 0.5)
