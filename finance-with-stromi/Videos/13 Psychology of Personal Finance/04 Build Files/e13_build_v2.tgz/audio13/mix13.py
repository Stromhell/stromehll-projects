# Finance with Stromi 12 What Happens If Everyone Stops Buying US Debt: full soundtrack (Kokoro voice + Kevin MacLeod music CC BY 4.0 + bigsoundbank SFX + synth foley), 48 kHz stereo.
import json, wave, numpy as np
from scipy.signal import lfilter, resample_poly
SR = 48000; FPS = 24; NACT = 8
rng = np.random.default_rng(13)
EV = json.load(open('/home/user/w13/audio/events13.json'))
TM = json.load(open('/home/user/w13/audio/vo/timing.json'))
SH = []; off = 0.0; ACT_LEN = []
for a in range(NACT):
    shots = EV[str(a)]['shots']; T = shots[-1]['start'] + shots[-1]['d']; L = round(T * FPS) / FPS
    for s in shots: SH.append(dict(s, g=off + s['start'], act=a))
    ACT_LEN.append(L); off += L
TOTAL = off; N = int(TOTAL * SR) + SR
print('total', round(TOTAL, 2), 's')
V = np.zeros(N); M = np.zeros((N, 2)); X = np.zeros((N, 2)); A = np.zeros((N, 2))
def put(buf, sig, t, g=1.0, pan=0.0):
    i = int(t * SR)
    if i < 0: sig = sig[-i:]; i = 0
    n = min(len(sig), N - i)
    if n <= 0: return
    if buf.ndim == 1: buf[i:i + n] += sig[:n] * g
    else: buf[i:i + n, 0] += sig[:n] * g * (1 - pan) * 0.8; buf[i:i + n, 1] += sig[:n] * g * (1 + pan) * 0.8
def ts(d): return np.arange(int(d * SR)) / SR
def env(n, a=0.005, d=0.3): t = np.arange(n) / SR; return np.minimum(t / a, 1) * np.exp(-t / d)
def noise(d): return rng.standard_normal(int(d * SR))
def lp(x, k): return lfilter([k], [1, k - 1], x)
def hp(x, k): return x - lp(x, k)
NOTE = lambda m: 440 * 2 ** ((m - 69) / 12)
def tone(f, dur, d=0.4, h=(1, .5, .25), a=0.004):
    t = ts(dur); return sum(x * np.sin(2 * np.pi * f * (k + 1) * t) for k, x in enumerate(h)) * env(len(t), a, d)
# ---------- real recordings (bigsoundbank.com, royalty-free; music: Kevin MacLeod incompetech.com CC BY 4.0) ----------
import subprocess, os
_C = {}
def load(path, ch=1):
    k = (path, ch)
    if k not in _C:
        r = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-ac', str(ch), '-ar', str(SR), '-f', 'f32le', '-'], capture_output=True, check=True)
        x = np.frombuffer(r.stdout, np.float32).astype(float); x = x.reshape(-1, ch) if ch > 1 else x
        _C[k] = x / (np.abs(x).max() + 1e-9)
    return _C[k]
SFXD = '/home/user/w13/audio/sfx/'
def smp(sid, a=None, d=None, fi=0.01, fo=0.05):
    x = load(SFXD + sid + '.mp3')
    if a is None: nz = np.where(np.abs(x) > 0.05)[0]; a = max(0, nz[0] / SR - 0.01) if len(nz) else 0
    elif a == 'rnd': a = rng.uniform(0, max(0.01, len(x) / SR - (d or 1) - 0.1))
    i0 = int(a * SR); y = x[i0:] if d is None else x[i0:i0 + int(d * SR)]
    if d is not None and len(y) < int(d * SR): y = np.tile(x, int(np.ceil(d * SR / len(x))) + 1)[i0:i0 + int(d * SR)]
    n = len(y); e = np.minimum(1, np.minimum(np.arange(n) / max(1, fi * SR), (n - np.arange(n)) / max(1, fo * SR))); return y * e
# ---------- foley ----------
def whoosh(d=0.55): n = int(d * SR); e = np.sin(np.pi * np.linspace(0, 1, n)) ** 2; return lp(noise(d), 0.07) * e * 1.6
def pop(): t = ts(0.12); f = 900 * np.exp(-t * 18) + 500; return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.002, 0.05) * 0.8 + lp(noise(0.12), 0.4) * env(len(t), 0.001, 0.01) * 0.4
def thud(f0=90, d=0.5): t = ts(d); f = f0 * np.exp(-t * 10) + 40; return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.001, 0.15) * 1.4 + lp(noise(d), 0.3) * env(len(t), 0.001, 0.02) * 0.8
def clink(): f = rng.uniform(2600, 4200); t = ts(0.25); return (np.sin(2 * np.pi * f * t) + 0.5 * np.sin(2 * np.pi * f * 2.76 * t)) * env(len(t), 0.0005, 0.05) * 0.35
def bell(f=523, d=2.5): t = ts(d); return sum(a * np.sin(2 * np.pi * f * r * t) for r, a in [(1, 1), (2.4, .6), (4.1, .4), (5.4, .25)]) * env(len(t), 0.001, 0.7) * 0.5
def ding(): return bell(1568, 1.2) * 0.6
def paper(d=0.3): n = int(d * SR); return lp(noise(d), 0.5) * np.abs(np.sin(np.linspace(0, 25, n))) * env(n, 0.01, 0.12) * 0.6
def flip(): return paper(0.18) * 0.8
def click(): t = ts(0.04); return lp(noise(0.04), 0.6) * env(len(t), 0.0005, 0.004) * 1.2
def creak(d=1.0): t = ts(d); f = 180 + 40 * np.sin(2 * np.pi * 1.3 * t); s = np.sign(np.sin(2 * np.pi * np.cumsum(f) / SR)) * 0.3; return lp(s, 0.2) * np.minimum(1, np.minimum(t, d - t) / 0.1) * 0.5
def buzz(d=0.33): t = ts(d); return np.sign(np.sin(2 * np.pi * 180 * t)) * (0.5 + 0.5 * np.sin(2 * np.pi * 24 * t)) * np.minimum(1, np.minimum(t, d - t) / 0.01) * 0.12
def thunder(): d = 3.5; t = ts(d); return lp(noise(d), 0.01) * (np.exp(-t / 1.2) * np.minimum(t / 0.05, 1)) * 9
def clack(): t = ts(0.06); return lp(noise(0.06), 0.5) * env(len(t), 0.0005, 0.008) + np.sin(2 * np.pi * 300 * t) * env(len(t), 0.0005, 0.01) * 0.4
def snip(): t = ts(0.12); return hp(noise(0.12), 0.3) * env(len(t), 0.001, 0.02) * 0.8
def cheer(d): t = ts(d); return lp(noise(d), 0.12) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.7 * t)) * np.minimum(1, np.minimum(t, d - t) / 0.6) * 1.2
def gull(): t = ts(0.5); f = 1400 - 600 * t; return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.02, 0.15) * 0.15
def tick(): t = ts(0.03); return np.sin(2 * np.pi * 2500 * t) * env(len(t), 0.0005, 0.004) * 0.4
def register():
    d = np.concatenate([np.zeros(int(0.12 * SR)), ding()]); d[:int(0.2 * SR)] += thud(200, 0.2) * 0.4; return d
# ---------- ambience beds by set ----------
def amb_synth(kind, d):
    t = ts(d); n = len(t); f = lambda k, g: lp(rng.standard_normal(n), k) * g
    if kind == 'hum': return np.sin(2 * np.pi * 60 * t) * 0.02 + np.sin(2 * np.pi * 120 * t) * 0.012 + f(0.02, 0.15)
    return f(0.015, 0.25)
def amb(kind, d):
    if kind == 'diner': return smp('1193', 'rnd', d, 0.2, 0.2) * 1.0 + smp('3515', 'rnd', d, 0.2, 0.2) * 0.35
    if kind == 'porch': return smp('0595', 'rnd', d, 0.2, 0.2) * 0.5
    if kind == 'office': return smp('0502', 'rnd', d, 0.2, 0.2) * 0.8
    if kind == 'crowd': return smp('3515', 'rnd', d, 0.2, 0.2) * 0.8
    if kind == 'town': return smp('0595', 'rnd', d, 0.2, 0.2) * 0.4 + smp('3515', 'rnd', d, 0.2, 0.2) * 0.25
    return amb_synth(kind, d)
SET = {}
for k_, ids in {'town': 'P01 P48', 'night': 'P24 P25 P27 P28', 'room': 'P02 P03 P26 P49 P47 P43 P44 P45', 'office': 'P04 P16 P17 P18 P19 P20 P21 P22 P37 P38 P39 P40 P41', 'vault': 'P07 P08 P09 P11 P12 P13 P14', 'crowd': 'P10 P30 P31 P32 P33 P34 P35'}.items():
    for i_ in ids.split(): SET[i_] = k_
AG = {'crowd': 0.45, 'diner': 0.6, 'room': 0.5, 'office': 0.5, 'yard': 0.7, 'green': 0.6, 'night': 0.8, 'town': 0.6, 'store': 0.6, 'vault': 0.6}
def wind(d): t = ts(d); n = len(t); return lp(rng.standard_normal(n), 0.01) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.13 * t + rng.uniform(0, 6))) * 0.9 + lp(rng.standard_normal(n), 0.04) * 0.15
def crickets(d):
    t = ts(d); c = np.sin(2 * np.pi * 4300 * t) * (np.sin(2 * np.pi * 28 * t) > 0.3) * (np.sin(2 * np.pi * 1.1 * t) > -0.2); return c * 0.08 + lp(rng.standard_normal(len(t)), 0.01) * 0.3
def amb11(k, d):
    if k == 'yard': return smp('0595', 'rnd', d, 0.2, 0.2) * 0.6 + wind(d) * 0.35
    if k == 'green': return smp('0595', 'rnd', d, 0.2, 0.2) * 0.4 + amb_synth('hum', d) * 0.4
    if k == 'night': return crickets(d) + wind(d) * 0.3
    if k == 'store': return amb_synth('hum', d) * 0.6 + smp('3515', 'rnd', d, 0.2, 0.2) * 0.3
    if k == 'vault': return amb_synth('hum', d) * 0.7
    return amb(k, d)
for s in SH:
    if s['card'] is not False: continue
    k = SET.get(s['id'], 'room'); a = amb11(k, s['d'] + 0.3); e = np.minimum(1, np.minimum(ts(s['d'] + 0.3), s['d'] + 0.3 - ts(s['d'] + 0.3)) / 0.25)
    put(A, a * e, s['g'] - 0.15, 0.12 * AG[k], 0)
# ---------- voice + duck envelope ----------
duck = np.ones(N)
for s in SH:
    if s['card'] is not False or s['id'] not in TM or not TM[s['id']]['lines']: continue
    w = wave.open(f"/home/user/w13/audio/vo/{s['id']}.wav"); sr0 = w.getframerate(); x = np.frombuffer(w.readframes(w.getnframes()), '<i2').astype(float) / 32768; w.close()
    x = resample_poly(x, SR // 8000, sr0 // 8000) if sr0 != SR else x; x = hp(x, 0.012)
    put(V, x, s['g'], 1.0)
    for l in TM[s['id']]['lines']:
        i0 = int((s['g'] + l['t0'] - 0.1) * SR); i1 = int((s['g'] + l['t1'] + 0.2) * SR); duck[max(0, i0):i1] = 0.22
duck = lfilter([0.0015], [1, -0.9985], duck)
# ---------- music: one Kevin MacLeod track per mood, continuing where it stopped; card stings ----------
TRK = {'tense': 'Hidden Agenda', 'bouncy': 'Sneaky Snitch', 'curious': 'Investigations', 'thought': 'Thinking Music', 'warm': 'Carefree', 'serious': 'Dark Times', 'sparse': 'Gymnopedie No 1', 'hep': 'Hep Cats', 'wall': 'Wallpaper', 'party': 'Fluffing a Duck', 'show': 'Monkeys Spinning Monkeys', 'easy': 'Easy Lemon', 'polka': 'Pixel Peeker Polka - faster', 'sneak': 'Sneaky Snitch', 'march': 'Bumbly March'}
MOODS = [('hep', 'P01'), ('bouncy', 'P02'), ('curious', 'P03'), ('show', 'P04'), ('polka', 'P07'), ('curious', 'P08'), ('thought', 'P09'), ('party', 'P10'), ('sneak', 'P11'), ('tense', 'P12'), ('easy', 'P13'), ('thought', 'P14'),
         ('polka', 'P16'), ('thought', 'P17'), ('serious', 'P18'), ('march', 'P19'), ('curious', 'P20'), ('easy', 'P21'), ('warm', 'P22'), ('wall', 'P24'), ('curious', 'P25'), ('bouncy', 'P26'), ('sparse', 'P27'), ('thought', 'P28'),
         ('show', 'P30'), ('tense', 'P31'), ('serious', 'P32'), ('sneak', 'P33'), ('thought', 'P34'), ('hep', 'P35'), ('march', 'P37'), ('easy', 'P38'), ('curious', 'P39'), ('party', 'P40'), ('tense', 'P41'),
         ('warm', 'P43'), ('sneak', 'P44'), ('easy', 'P45'), ('warm', 'P47'), ('hep', 'P48'), ('warm', 'P49'), ('sparse', 'P50')]
MO = {i: m for m, ids in MOODS for i in ids.split()}
runs = []
for s in SH:
    if s['card'] is not False and s['id'] != 'P50':
        r0 = 45  # chapter card sting: rising piano + whoosh
        for k, mm in enumerate([r0 + 24, r0 + 28, r0 + 31, r0 + 36]): put(M, tone(NOTE(mm), 1.6, 0.6, (1, .45, .2, .08)), s['g'] + 0.15 + k * 0.18, 0.16, (k - 1.5) * 0.2)
        put(X, smp('1796', None, 1.1), s['g'] - 0.4, 0.6); continue
    st = MO[s['id']]
    if runs and runs[-1][0] == st and abs(runs[-1][2] - s['g']) < 0.05: runs[-1][2] = s['g'] + s['d']
    else: runs.append([st, s['g'], s['g'] + s['d']])
pos = {}
for st, g0, g1 in runs:
    x = load('/home/user/w13/audio/mus/' + TRK[st] + '.mp3', 2); d = g1 - g0 + 1.0; o = pos.get(st, 0.0)
    n = int(d * SR); i0 = int(o * SR) % len(x); y = np.concatenate([x[i0:], x, x])[:n]
    pos[st] = (o + d) % (len(x) / SR)
    e = np.minimum(1, np.minimum(np.arange(n) / SR / 1.0, (n - np.arange(n)) / SR / 1.0))[:, None]
    i = max(0, int((g0 - 0.5) * SR)); m = min(n, N - i); M[i:i + m] += (y * e)[:m] * 0.5
# ---------- cuts + motion-graphics / tag pops ----------
for s in SH[1:]: put(X, whoosh(0.5), s['g'] - 0.3, 0.35)
aoff = [sum(ACT_LEN[:a]) for a in range(NACT)]
for a in range(NACT):
    for tt in EV[str(a)]['pops']: put(X, pop(), aoff[a] + tt + 0.1, 0.35, rng.uniform(-0.3, 0.3))
# ---------- per-shot foley ----------
G = {s['id']: s for s in SH}
def at(i, lt, sig, g=1.0, pan=0.0): put(X, sig, G[i]['g'] + lt, g, pan)
def coins(i, t0, t1, rate):  # real coin pours, layered for density
    d = t1 - t0
    if d <= 0: return
    for k in range(1 + int(rate > 11)): at(i, t0, smp(('0194', '0193')[k], 'rnd', d, 0.05, 0.3), 0.5 + rate / 30, (-0.3, 0.4)[k])
# real-recording replacements for the synth foley
ding = lambda: smp('2531', None, 1.6) * 0.8
bell = lambda f=660, d=3.0: smp('1927', None, min(d, 4.0)) * 0.9
gull = lambda: smp('2573', 'rnd', 2.0, 0.1, 0.4) * 0.8
thunder = lambda: smp('3115', 'rnd', 3.5, 0.02, 0.8) * 1.2
paper = lambda d=0.3: smp('1250', 'rnd', max(0.25, d), 0.01, 0.08) * 0.9
flip = lambda: smp('1250', 'rnd', 0.3, 0.01, 0.08) * 0.8
def ticks(i, t0, t1, g=0.6): at(i, t0, smp('2816', 'rnd', t1 - t0, 0.05, 0.1), g)
_ST = {}
def step_hits(sid):  # cut single footsteps out of a real recording by onset
    if sid not in _ST:
        x = load(SFXD + sid + '.mp3'); e = np.convolve(np.abs(x), np.ones(240) / 240, 'same'); th = e.max() * 0.25; on = []
        i = 0
        while i < len(e):
            if e[i] > th: on.append(i); i += int(0.3 * SR)
            else: i += 48
        _ST[sid] = [x[max(0, o - 240): o + int(0.22 * SR)] * np.minimum(1, (int(0.22 * SR) + 240 - np.arange(len(x[max(0, o - 240): o + int(0.22 * SR)]))) / 2400) for o in on]
    return _ST[sid]
def steps(i, t0, t1, g=0.5, every=0.75, sid='0514'):  # one real footstep per stride, timed to the walk cycle
    h = step_hits(sid)
    for k, t in enumerate(np.arange(t0, t1, every)): at(i, t + rng.uniform(-0.02, 0.02), h[rng.integers(len(h))], g * rng.uniform(0.8, 1.0), (-0.15, 0.15)[k % 2])
def keys(i, t0, t1, g=0.5): at(i, t0, smp('0229', 'rnd', t1 - t0, 0.05, 0.1), g)

def L(i, who, n=0):
    l = [x for x in TM.get(i, {}).get('lines', []) if x['who'] == who]; return l[n] if len(l) > n else None
D = lambda i: G[i]['d']
def clinks(i, t0, t1, n): [at(i, t, clink(), 0.7, rng.uniform(-0.3, 0.3)) for t in np.linspace(t0, t1, n)]
# ---------- per-shot foley (video 03) ----------
def reg_beep(): t = ts(0.12); return np.sin(2 * np.pi * 1800 * t) * env(len(t), 0.002, 0.08) * 0.5
def tap_ok(): return np.concatenate([reg_beep(), np.zeros(int(0.06 * SR)), reg_beep()])
def roll(d): t = ts(d); return lp(noise(d), 0.05) * (0.6 + 0.4 * np.sin(2 * np.pi * 9 * t)) * np.minimum(1, (d - t) / 0.2) * 0.8
def engine(d): t = ts(d); return lp(np.sign(np.sin(2 * np.pi * 38 * t)) * 0.4 + noise(d) * 0.2, 0.08) * np.minimum(1, np.minimum(t, d - t) / 0.3)
def sputter(): d = 2.0; t = ts(d); return engine(d) * (np.sin(2 * np.pi * 3 * t) > 0) * np.exp(-t * 0.8)
def stamp(): return thud(120, 0.4) * 1.2
def saw_s(): n = int(0.12 * SR); return hp(noise(0.12), 0.4) * env(n, 0.005, 0.05)
def TM_(i, q):
    for l in TM.get(i, {}).get('lines', []):
        tx = l['text'].lower()
        if q.lower() in tx: return l['t0'] + (l['t1'] - l['t0']) * tx.index(q.lower()) / len(tx)
    print('foley anchor miss', i, q); return 0.5

def spray(d=1.5): return smp('0740', 'rnd', d, 0.02, 0.4) * 1.5
def bleep(n, gap=0.12, f=1200):
    t = ts(0.07); b = np.sin(2 * np.pi * f * t) * env(len(t), 0.002, 0.04) * 0.4; return np.concatenate([np.concatenate([b, np.zeros(int(gap * SR))]) for _ in range(n)])
def errbuzz(): return lp(np.concatenate([buzz(0.18), np.zeros(int(0.08 * SR)), buzz(0.18)]), 0.15) * 3.0
def powerdown(): t = ts(0.8); f = 600 * np.exp(-t * 3) + 60; return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.005, 0.4) * 0.4
def flaps(i, t0, t1, g=0.6): ticks(i, t0, t1, g); [at(i, t, clack(), 0.35, rng.uniform(-0.4, 0.4)) for t in np.arange(t0, t1, 0.11)]
def Lt(i, who, n=0, k='t0'): l = L(i, who, n); return l[k] if l else 0.5

def water(d, g=1.0): t = ts(d); return (hp(noise(d), 0.35) * 0.25 + lp(noise(d), 0.08) * 0.8) * np.minimum(1, np.minimum(t, d - t) / 0.3) * g
def gurgle(d): t = ts(d); return lp(noise(d), 0.03) * (0.5 + 0.5 * np.sin(2 * np.pi * 5 * t) ** 2) * np.minimum(1, np.minimum(t, d - t) / 0.3) * 1.5
def sweep(d): t = ts(d); return hp(noise(d), 0.25) * (0.3 + 0.7 * np.abs(np.sin(2 * np.pi * 0.48 * t))) * 0.35
def squeak(): t = ts(0.25); f = 1800 + 400 * np.sin(2 * np.pi * 9 * t); return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.01, 0.12) * 0.12
def rattle(d): t = ts(d); return lp(noise(d), 0.25) * (0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 6 * t))) * 0.35
def flutter(d): t = ts(d); return hp(noise(d), 0.2) * (0.4 + 0.6 * np.abs(np.sin(2 * np.pi * 7 * t))) * np.minimum(1, (d - t) / 0.3) * 0.5
G2 = lambda i, w, n=0, k='t0': Lt(i, w, n, k)
# ---------- per-shot foley (video 08) ----------
def notif(): return np.concatenate([tone(NOTE(76), 0.12, 0.08), tone(NOTE(83), 0.3, 0.2)]) * 0.2
def sad_tb(): return np.concatenate([tone(NOTE(m), 0.45, 0.35, (1, .6, .3)) for m in (55, 54, 53)] + [tone(NOTE(52), 1.2, 0.8, (1, .6, .3))]) * 0.3
def ring(): t = ts(1.6); r = (np.sin(2 * np.pi * 440 * t) + np.sin(2 * np.pi * 480 * t)) * (np.sin(2 * np.pi * 20 * t) > 0) * (t % 0.8 < 0.55); return lp(r, 0.5) * np.minimum(1, (1.6 - t) / 0.05) * 0.25
def doorbell(): return smp('2531', None, 1.6) * 0.8
fl = lambda i, t0, d=1.2, g=0.5: flaps(i, t0, t0 + d, g)
gs = lambda i, t: min(max(0.2, t), D(i) - 0.3)
cbell = lambda: smp('2531', None, 1.6) * 0.8
wt = lambda i, w, n=0: G2(i, w, n)
# ---------- per-shot foley (video 11) ----------
def caw(): t = ts(0.35); f = 650 - 350 * t; s = np.sign(np.sin(2 * np.pi * np.cumsum(f) / SR)) * (0.6 + 0.4 * np.sin(2 * np.pi * 70 * t)); return lp(s, 0.25) * env(len(t), 0.01, 0.18) * 0.35
def caws(i, t0, n=3): [at(i, t0 + k * 0.42 + rng.uniform(0, 0.08), caw(), 0.45, rng.uniform(-0.5, 0.5)) for k in range(n)]
def drumroll(d): t = ts(d); return lp(noise(d), 0.2) * (0.55 + 0.45 * np.abs(np.sin(2 * np.pi * 14 * t))) * np.minimum(1, t / max(0.01, d)) * 0.7
def sizzle(d): t = ts(d); n = len(t); c = hp(noise(d), 0.5) * (rng.random(n) > 0.985) * 2.0; return (hp(noise(d), 0.35) * 0.25 + c) * np.minimum(1, np.minimum(t, d - t) / 0.3)
def scrib(d): t = ts(d); return hp(noise(d), 0.45) * (0.3 + 0.7 * np.abs(np.sin(2 * np.pi * 5 * t))) * 0.3
def lever(): return np.concatenate([creak(0.35) * 0.6, clack() * 2])
def pecks(i, t0, t1, g=0.5): [at(i, t, clack(), g, rng.uniform(-0.3, 0.3)) for t in np.arange(t0, t1, 0.22)]
def honk(): t = ts(0.5); return lp(np.sign(np.sin(2 * np.pi * 410 * t)) + np.sign(np.sin(2 * np.pi * 520 * t)), 0.3) * np.minimum(1, (0.5 - t) / 0.05) * 0.12
def tear(): return hp(noise(0.5), 0.3) * env(int(0.5 * SR), 0.01, 0.25) * 0.6
def cannon():
    x = thud(60, 0.7) * 1.5; p = pop(); i = int(0.05 * SR); x[i:i + len(p)] += p; return x
q = lambda i, ph: gs(i, TM_(i, ph))# ---------- per-shot foley (video 13, Head Office) ----------
def murmur(i, t0, t1, g=0.12): at(i, t0, cheer(max(0.5, t1 - t0)), g)
def flurry(i, t0, t1, g=0.5): [at(i, t, paper(0.25), g, rng.uniform(-0.5, 0.5)) for t in np.arange(t0, t1, 0.14)]
def bleeps(i, t0, t1, g=0.25): [at(i, t, bleep(1, 0.05, rng.choice([900, 1200, 1500])), g, rng.uniform(-0.6, 0.6)) for t in np.arange(t0, t1, 0.37)]
def stampx(i, t): at(i, t, stamp(), 0.7)
def chips(i, t0, n=8): [at(i, t0 + k * 0.07, clink(), 0.6, rng.uniform(-0.3, 0.3)) for k in range(n)]
def hl(i, w, n=0): return gs(i, Lt(i, w, n))
# P01 streetcar bell, envelope handed over, Hattie's gasp
at('P01', 0.3, bell(), 0.5); at('P01', q('P01', 'twelve hundred') - 1.2, paper(0.4), 0.6); at('P01', q('P01', 'twelve hundred'), ding(), 0.5)
steps('P01', 0.2, 2.0, 0.25, 0.8)
# P02 espresso machine drops onto the counter, steam puffs
at('P02', 0.65, thud(110, 0.5), 1.0); at('P02', 0.7, clink(), 0.6); at('P02', 0.75, spray(1.2), 0.25); at('P02', 0.9, register(), 0.4)
# P03 ticker tape prints, iris closes
at('P03', q('P03', 'six hundred') - 1.0, scrib(2.4), 0.5); at('P03', D('P03') - 1.0, whoosh(0.9), 0.6)
# P04 lift ding, memos flutter, staff bustle
at('P04', 0.4, ding(), 0.5); flurry('P04', 0.3, min(q('P04', 'five departments'), 6), 0.25); steps('P04', 0.3, 6.0, 0.2, 0.45)
for k in range(5): at('P04', q('P04', 'five departments') + k * 0.9, pop(), 0.3)
# P07 ladder creaks, dollar flurry
for t in np.arange(0.3, D('P07') - 0.5, 1.7): at('P07', t, creak(0.6), 0.25)
flurry('P07', hl('P07', 'PIGEONHOLE'), D('P07') - 0.5, 0.25)
# P08 two bills slap down, magnifier
at('P08', 0.5, paper(0.3), 0.7); at('P08', 0.8, paper(0.3), 0.7); at('P08', q('P08', 'look closer'), whoosh(0.5), 0.5); at('P08', q('P08', 'look closer') + 0.3, ding(), 0.3)
# P09 portrait frame, Nobel stamp
at('P09', 0.4, thud(160, 0.3), 0.5); stampx('P09', q('P09', 'nobel'))
# P10 casino murmur, chips pushed
murmur('P10', 0.2, D('P10') - 0.2, 0.18); chips('P10', hl('P10', 'ACE')); chips('P10', hl('P10', 'ACE') + 0.6, 6)
# P11 padlock click
at('P11', 0.6, click(), 1.2); at('P11', 0.65, clack(), 0.6)
# P12 meters count up, Pigeonhole slams the drawers shut
ticks('P12', q('P12', 'six hundred and seventy') - 1.0, q('P12', 'six hundred and seventy') + 1.5, 0.5); at('P12', hl('P12', 'PIGEONHOLE'), thud(120, 0.4), 0.8)
# P13 meter counts down, cards pop
ticks('P13', q('P13', 'keeps a thousand') + 1.0, q('P13', 'four hundred and forty'), 0.5); at('P13', q('P13', 'four hundred and forty'), register(), 0.4)
# P14 one page fills column by column
for ph_ in ['what you own', 'what you owe', 'what bills']: at('P14', q('P14', ph_), flip(), 0.7)
steps('P14', 0.3, 2.2, 0.25, 0.4)
# P16 switchboard chaos
bleeps('P16', 0.2, D('P16') - 0.2, 0.22); [at('P16', t, ring(), 0.25, rng.uniform(-0.5, 0.5)) for t in np.arange(0.5, D('P16') - 1.6, 3.1)]
# P17 the same call every payday
ticks('P17', 0.4, min(D('P17') - 0.3, hl('P17', 'OPAL')), 0.35); [at('P17', t, bleep(1, 0.05, 1200), 0.2) for t in np.arange(0.3, D('P17') - 0.3, 0.8)]
# P18 chalk rubbed out and rewritten
at('P18', q('P18', 'repeat studies') - 0.3, sweep(0.6), 0.6); at('P18', q('P18', 'repeat studies') + 0.2, scrib(1.4), 0.6)
# P19 Otto's door, footsteps, light turns green
at('P19', 0.2, creak(0.8), 0.5); steps('P19', 0.8, 3.4, 0.4, 0.5); at('P19', hl('P19', 'OTTO') + 1.5, ding(), 0.5); at('P19', hl('P19', 'OTTO') + 1.4, lever(), 0.5)
# P20 calm clicks
for t in np.arange(0.5, D('P20') - 0.5, 2.3): at('P20', t, click(), 0.6)
# P21 split board, tea cup
at('P21', 0.6, lever(), 0.6); at('P21', hl('P21', 'OPAL'), clink(), 0.6)
# P22 typing the index card, board powers down
keys('P22', hl('P22', 'HATTIE') + 0.2, hl('P22', 'HATTIE') + 2.2, 0.5); at('P22', hl('P22', 'HATTIE') + 2.5, powerdown(), 0.5)
# P24 night walk with the box
steps('P24', 0.2, hl('P24', 'WHAT-ELSE'), 0.4, 0.55); at('P24', hl('P24', 'WHAT-ELSE') - 0.4, whoosh(0.8), 0.4)
# P25 the ghost glides window to window
at('P25', q('P25', 'opportunity cost'), whoosh(0.9), 0.5); at('P25', q('P25', 'put on her credit card'), whoosh(0.9), 0.5); at('P25', q('P25', 'put on her credit card') + 0.8, ding(), 0.3)
# P26 sheet over the espresso machine, cat purr (low rumble)
at('P26', 0.3, paper(0.5), 0.6); at('P26', 0.5, gurgle(max(1.0, D('P26') - 1.0)), 0.12)
# P27 rain and a split boot sole
at('P27', 0.0, water(D('P27')), 0.4); at('P27', 0.6, thunder(), 0.35); at('P27', 0.8, squeak(), 0.6); at('P27', 1.6, squeak(), 0.5)
# P28 scorecard ticks
for ph_ in ['what does it cost', 'what do i get', 'what could go wrong', 'can i undo']: at('P28', q('P28', ph_), scrib(0.5), 0.6); at('P28', q('P28', ph_) + 0.1, pop(), 0.3)
# P30 circus: drumroll as Ace climbs, crowd gasp
murmur('P30', 0.2, D('P30') - 0.2, 0.12); at('P30', 0.4, drumroll(max(0.6, min(hl('P30', 'ACE') - 0.5, 6) - 0.4)), 0.6); at('P30', hl('P30', 'ACE'), cheer(2.0), 0.35)
# P31 meters pop on
at('P31', q('P31', 'risk tolerance'), thud(150, 0.3), 0.6); at('P31', q('P31', 'risk capacity'), thud(150, 0.3), 0.6); at('P31', q('P31', 'giant heart'), whoosh(0.7), 0.5)
# P32 wire wobbles, crash arrows
for t in np.arange(0.4, D('P32') - 0.5, 1.4): at('P32', t, creak(0.5), 0.3)
at('P32', 0.6, thud(80, 0.6), 0.7); at('P32', q('P32', '2008'), thud(70, 0.8), 0.9); at('P32', hl('P32', 'ACE'), cheer(1.2), 0.25)
# P33 low wire with a net
murmur('P33', 0.2, D('P33') - 0.2, 0.1); at('P33', q('P33', 'jump off'), sad_tb(), 0.35)
# P34 Ace climbs down, three questions
for t in np.arange(0.3, 3.2, 0.35): at('P34', t, clack(), 0.35)
for ph_ in ['what happens if', 'how long', 'would being wrong']: at('P34', q('P34', ph_), pop(), 0.4)
# P35 practice wire, pillow, scores
at('P35', 1.0, ding(), 0.4); at('P35', 1.1, cheer(1.8), 0.3); at('P35', hl('P35', 'ACE'), thud(90, 0.4), 0.5)
# P37 typewriter
keys('P37', 0.4, min(D('P37') - 0.3, 4.5), 0.45); at('P37', min(D('P37') - 0.3, 4.6), cbell(), 0.4)
# P38-P41 rules stamped onto the plaque
stampx('P38', q('P38', 'rule one')); stampx('P39', q('P39', 'rule two')); stampx('P39', q('P39', 'rule three')); stampx('P40', q('P40', 'rule four')); stampx('P41', q('P41', 'rule five')); stampx('P41', q('P41', 'rule six'))
at('P39', q('P39', 'rule two') + 1.0, ticks if False else pop(), 0.3)
at('P40', 0.3, engine(1.8), 0.35); at('P40', 2.0, honk(), 0.6); at('P40', q('P40', 'over six years'), flip(), 0.8); at('P40', q('P40', 'over six years') + 0.4, register(), 0.35)
at('P41', 0.8, paper(0.3), 0.6); at('P41', q('P41', 'warning sign'), rattle(1.6), 0.7); at('P41', q('P41', 'warning sign') + 0.2, saw_s(), 0.6)
# P43 four easels fill in
for ph_ in ['what you own', 'what you owe', 'what leaves', 'what you actually want']: at('P43', q('P43', ph_), scrib(0.9), 0.55)
# P44 lines drawn, the gym blinks
at('P44', 1.0, scrib(2.0), 0.55); [at('P44', t, bleep(1, 0.05, 700), 0.2) for t in np.arange(1.2, hl('P44', 'HATTIE'), 0.8)]; at('P44', hl('P44', 'HATTIE'), sad_tb(), 0.3)
# P45 sticky note slapped on
at('P45', q('P45', 'pick the one') + 0.2, paper(0.25), 0.8); at('P45', q('P45', 'pick the one') + 0.3, thud(200, 0.2), 0.5)
# P47 five rule cards pop up
for ph_ in ['one.', 'two.', 'three.', 'four.', 'and five']:
    try: at('P47', q('P47', ph_), pop(), 0.6)
    except Exception: pass
# P48 a few months later: same streetcar, same bonus, quick trip into the head
at('P48', 0.3, bell(), 0.45); at('P48', q('P48', 'same twelve hundred') - 1.0, paper(0.4), 0.6); at('P48', q('P48', 'checked the rules') - 0.4, whoosh(0.7), 0.6); at('P48', hl('P48', 'HATTIE') - 0.3, whoosh(0.7), 0.6); at('P48', hl('P48', 'PIGEONHOLE'), ding(), 0.4)
# P49 kitchen: SOLD tag, pot bubbling, cake
at('P49', 0.5, register(), 0.4); at('P49', 0.3, gurgle(max(1.0, D('P49') - 1.5)), 0.18); at('P49', hl('P49', 'HATTIE'), clink(), 0.5)
# ---------- mix ----------
# voice polish (pedalboard, free): gentle EQ + compression on everything; a small room on character lines so they sit in the scene
import pedalboard as pb, pyloudnorm as pyln
import gc
f32 = np.float32
V = V.astype(f32); M = M.astype(f32); X = X.astype(f32); A = A.astype(f32); duck = duck.astype(f32); gc.collect()
cm = np.zeros(N, f32)
for s in SH:
    if s['card'] is not False or s['id'] not in TM: continue
    for l in TM[s['id']]['lines']:
        if l['who'] != 'N': cm[int((s['g'] + l['t0']) * SR):int((s['g'] + l['t1'] + 0.4) * SR)] = 1
cm = lfilter([0.002], [1, -0.998], cm).astype(f32)
dry = pb.Pedalboard([pb.HighpassFilter(75), pb.LowShelfFilter(160, 1.5), pb.PeakFilter(3200, 1.5, 0.9), pb.Compressor(-22, 2.5, 8, 120)])(V[None, :], SR)[0]
del V; gc.collect()
wet = pb.Pedalboard([pb.Reverb(room_size=0.18, damping=0.6, wet_level=0.12, dry_level=0.9, width=0.0)])(dry[None, :], SR)[0]
Vn = dry * (1 - cm) + wet * cm; del dry, wet, cm; gc.collect()
Vn *= 0.9 / max(1e-9, np.abs(Vn).max())
out = np.repeat((Vn * 0.95)[:, None], 2, 1); del Vn
M *= 0.42 / max(1e-9, np.abs(M).max()); M *= (duck[:, None] * 0.95); out += M; del M
X *= 0.30 / max(1e-9, np.abs(X).max()); X *= (0.4 + 0.6 * duck[:, None]); out += X; del X
A *= 0.14 / max(1e-9, np.abs(A).max()); A *= (0.3 + 0.7 * duck[:, None]); out += A; del A; gc.collect()
out = out[:int(TOTAL * SR)]
fade = int(2.5 * SR); out[-fade:] *= np.linspace(1, 0, fade)[:, None]
lufs = pyln.Meter(SR).integrated_loudness(out); out *= 10 ** ((-14 - lufs) / 20)  # YouTube target
out = np.ascontiguousarray(pb.Pedalboard([pb.Limiter(-1.0, 80)])(np.ascontiguousarray(out.T), SR).T)
l2 = pyln.Meter(SR).integrated_loudness(out); out *= 10 ** ((-14 - l2) / 20)
out /= max(1.0, np.abs(out).max() / 0.89)
print('LUFS before', round(lufs, 1), 'peak', round(float(np.abs(out).max()), 3))
w = wave.open('/home/user/w13/audio/mix13_v1.wav', 'wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((out * 32767).astype('<i2').tobytes()); w.close()
json.dump({'act_len': ACT_LEN, 'total': TOTAL}, open('/home/user/w13/audio/acts13.json', 'w'))
print('ok', ACT_LEN)
